import React, { useState, useEffect } from 'react'
import { Table, Button, Space, Pagination, Modal, Message, Skeleton, Card, Tabs, Input, Select, Tag, Progress, Checkbox, Radio, Divider } from '@arco-design/web-react'
import axios from '../utils/axios'
import AdditionalAccounts from './AdditionalAccounts'
import RecipientManagement from './RecipientManagement'
import UserEmailRecords from './UserEmailRecords'
import './NewsInfo.css'

const Option = Select.Option
const TabPane = Tabs.TabPane
const InputSearch = Input.Search
const RadioGroup = Radio.Group

function NewsInfo() {
  const [newsList, setNewsList] = useState([])
  const [allFilteredNews, setAllFilteredNews] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [search, setSearch] = useState('')
  const [user, setUser] = useState(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [selectedNews, setSelectedNews] = useState(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showContentModal, setShowContentModal] = useState(false)
  const [userStats, setUserStats] = useState(null)
  const [activeTab, setActiveTab] = useState('yesterday')
  const [showExportModal, setShowExportModal] = useState(false)
  const [exportLoading, setExportLoading] = useState(false)
  const [adminActiveTab, setAdminActiveTab] = useState('news')
  const [recipientTab, setRecipientTab] = useState('recipients')
  const [selectedNewsIds, setSelectedNewsIds] = useState([])
  const [selectAll, setSelectAll] = useState(false)
  const [batchAnalysisLoading, setBatchAnalysisLoading] = useState(false)
  const [pageSize, setPageSize] = useState(10)
  const [analysisStatus, setAnalysisStatus] = useState(null)
  const [analysisProgress, setAnalysisProgress] = useState(null)
  const [currentTaskId, setCurrentTaskId] = useState(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [enterpriseFilter, setEnterpriseFilter] = useState('enterprise')

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (userData) {
      const userInfo = JSON.parse(userData)
      setUser(userInfo)
      setIsAdmin(userInfo.role === 'admin')
    }
  }, [])

  const fetchUserStats = async () => {
    if (!isAdmin) {
      try {
        const response = await axios.get('/api/news/user-stats')
        if (response.data.success) {
          setUserStats(response.data.data)
        }
      } catch (error) {
        console.error('获取统计信息失败:', error)
      }
    }
  }

  useEffect(() => {
    if (user !== null && !isAdmin) {
      fetchUserStats()
    }
  }, [user, isAdmin])

  const fetchNews = async () => {
    if (isAdmin && adminActiveTab !== 'news') {
      return
    }
    
    if (user === null) {
      return
    }
    
    setLoading(true)
    try {
      const MAX_FETCH_SIZE = 100000
      const params = {
        page: 1,
        pageSize: MAX_FETCH_SIZE,
        timeRange: activeTab
      }
      if (search) {
        params.search = search
      }
      
      const endpoint = isAdmin ? '/api/news/' : '/api/news/user-news'
      const response = await axios.get(endpoint, { params })
      
      if (response.data.success) {
        let allNewsData = response.data.data || []
        const fetchedCount = allNewsData.length
        const totalCount = response.data.total || 0
        
        if (fetchedCount >= MAX_FETCH_SIZE && totalCount > MAX_FETCH_SIZE) {
          console.warn(`数据量较大（${totalCount}条），当前显示前${MAX_FETCH_SIZE}条。建议使用搜索功能缩小范围。`)
        }
        
        if (enterpriseFilter === 'enterprise') {
          allNewsData = allNewsData.filter(news => news.enterprise_full_name && news.enterprise_full_name.trim() !== '')
        }
        
        allNewsData.sort((a, b) => {
          const aHasEnterprise = a.enterprise_full_name && a.enterprise_full_name.trim() !== ''
          const bHasEnterprise = b.enterprise_full_name && b.enterprise_full_name.trim() !== ''
          
          if (aHasEnterprise && !bHasEnterprise) return -1
          if (!aHasEnterprise && bHasEnterprise) return 1
          
          const timeA = a.public_time ? new Date(a.public_time).getTime() : 0
          const timeB = b.public_time ? new Date(b.public_time).getTime() : 0
          return timeB - timeA
        })
        
        const totalFiltered = allNewsData.length
        let finalTotal
        if (totalCount > MAX_FETCH_SIZE) {
          finalTotal = totalFiltered
          if (enterpriseFilter === 'enterprise') {
            console.warn(`数据量较大，当前显示企业相关新闻 ${totalFiltered} 条（实际获取 ${fetchedCount} 条，后端总数 ${totalCount} 条）。建议使用搜索功能缩小范围。`)
          }
        } else {
          finalTotal = totalFiltered
        }
        
        setAllFilteredNews(allNewsData)
        setTotal(finalTotal)
      } else {
        console.error('获取舆情信息失败:', response.data.message)
        setAllFilteredNews([])
        setNewsList([])
        setTotal(0)
        throw new Error(response.data.message || '获取舆情信息失败')
      }
    } catch (error) {
      if (error.code === 'ECONNREFUSED' || error.message?.includes('ECONNREFUSED')) {
        console.warn('后端服务器连接被拒绝，可能正在启动中...')
        setNewsList([])
        setTotal(0)
        throw error
      }
      console.error('获取舆情信息失败:', error)
      setAllFilteredNews([])
      setNewsList([])
      setTotal(0)
      if (currentPage === 1 && !search) {
        throw new Error('获取舆情信息失败：' + (error.response?.data?.message || error.message || '未知错误'))
      }
      throw error
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let isMounted = true
    
    const loadData = async () => {
      try {
        await fetchNews()
      } catch (error) {
        if (isMounted && currentPage === 1 && !search) {
          if (error.message && !error.message.includes('ECONNREFUSED')) {
            Message.error(error.message)
          }
        }
      }
    }
    
    if (isAdmin && adminActiveTab !== 'news') {
      return
    }
    
    if (user === null) {
      return
    }
    
    loadData()
    
    return () => {
      isMounted = false
    }
  }, [search, isAdmin, user, activeTab, pageSize, adminActiveTab, enterpriseFilter])

  useEffect(() => {
    if (allFilteredNews.length === 0) {
      setNewsList([])
      return
    }
    
    const startIndex = (currentPage - 1) * pageSize
    const endIndex = startIndex + pageSize
    const paginatedData = allFilteredNews.slice(startIndex, endIndex)
    
    setNewsList(paginatedData)
  }, [currentPage, pageSize, allFilteredNews])

  const shouldShowCheckbox = () => {
    return ['yesterday', 'thisWeek', 'lastWeek', 'thisMonth', 'all'].includes(activeTab)
  }

  const handleTabChange = (tab) => {
    setActiveTab(tab)
    setCurrentPage(1)
    setSelectedNewsIds([])
    setSelectAll(false)
  }

  const handlePageSizeChange = (newPageSize) => {
    setPageSize(newPageSize)
    setCurrentPage(1)
    setSelectedNewsIds([])
    setSelectAll(false)
  }

  const checkAnalysisStatus = async () => {
    try {
      const response = await axios.get('/api/news-analysis/analysis-status')
      if (response.data.success) {
        setAnalysisStatus(response.data.data)
        if (response.data.data.isProcessing) {
          setTimeout(checkAnalysisStatus, 3000)
        }
      }
    } catch (error) {
      console.error('检查分析状态失败:', error)
    }
  }

  const checkAnalysisProgress = async (taskId) => {
    try {
      const response = await axios.get(`/api/news-analysis/analysis-progress/${taskId}`)
      if (response.data.success) {
        const progressData = response.data.data
        setAnalysisProgress(progressData)
        
        if (progressData.status === 'processing') {
          setTimeout(() => checkAnalysisProgress(taskId), 2000)
        } else if (progressData.status === 'completed') {
          setTimeout(() => {
            setAnalysisProgress(null)
            setCurrentTaskId(null)
            fetchNews()
          }, 3000)
        } else if (progressData.status === 'not_found') {
          setAnalysisProgress(null)
          setCurrentTaskId(null)
        }
      }
    } catch (error) {
      console.error('检查分析进度失败:', error)
      setAnalysisProgress(null)
      setCurrentTaskId(null)
    }
  }

  const cleanInvalidAssociations = async () => {
    Modal.confirm({
      title: '确认清理',
      content: '此操作将检查所有新闻的企业关联，并清理不在被投企业数据库中的关联。\n\n这可能会影响大量数据，是否继续？',
      onOk: async () => {
        try {
          const response = await axios.post('/api/news-analysis/clean-invalid-associations')
          if (response.data.success) {
            const result = response.data.data
            let resultMessage = `清理完成！\n\n` +
              `检查了 ${result.totalChecked} 条新闻\n` +
              `清理了 ${result.cleanedCount} 个无效企业关联\n\n`
            
            if (result.invalidEnterprises.length > 0) {
              resultMessage += `清理的无效企业示例：\n`
              result.invalidEnterprises.slice(0, 5).forEach(item => {
                resultMessage += `• ${item.invalidEnterprise}\n`
              })
              if (result.invalidEnterprises.length > 5) {
                resultMessage += `... 还有 ${result.invalidEnterprises.length - 5} 个\n`
              }
            }
            Message.success(resultMessage.replace(/\n/g, ' '))
            fetchNews()
          } else {
            Message.error('清理失败：' + response.data.message)
          }
        } catch (error) {
          console.error('清理无效关联失败:', error)
          Message.error('清理失败：' + (error.response?.data?.message || error.message))
        }
      }
    })
  }

  const cancelAnalysis = () => {
    Modal.confirm({
      title: '确认取消',
      content: '确定要取消当前的AI分析吗？\n\n已处理的数据不会回滚。',
      onOk: () => {
        setAnalysisProgress(null)
        setCurrentTaskId(null)
        Message.info('已取消AI分析监控\n\n注意：后台分析可能仍在继续，但不再显示进度。')
      }
    })
  }

  const handleRefreshList = async () => {
    if (isRefreshing || loading) return
    
    setIsRefreshing(true)
    try {
      await fetchNews()
    } catch (error) {
      console.error('刷新新闻列表失败:', error)
      Message.error('刷新失败，请稍后重试')
    } finally {
      setTimeout(() => {
        setIsRefreshing(false)
      }, 800)
    }
  }

  const handleSearch = () => {
    setCurrentPage(1)
  }

  const totalPages = Math.ceil(total / pageSize)

  const formatDate = (dateString) => {
    if (!dateString) return '-'
    try {
      const date = new Date(dateString)
      return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      })
    } catch (e) {
      return dateString
    }
  }

  const formatDateWithLineBreak = (dateString) => {
    if (!dateString) return '-'
    try {
      const date = new Date(dateString)
      const dateStr = date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      })
      const timeStr = date.toLocaleTimeString('zh-CN', {
        hour: '2-digit',
        minute: '2-digit'
      })
      return `${dateStr}\n${timeStr}`
    } catch (e) {
      return dateString
    }
  }

  const handleViewDetail = (news) => {
    setSelectedNews(news)
    setShowDetailModal(true)
  }

  const handleViewContent = (news) => {
    setSelectedNews(news)
    setShowContentModal(true)
  }

  const handleDelete = async (newsId) => {
    Modal.confirm({
      title: '确认删除',
      content: '确定要删除这条新闻记录吗？此操作不可恢复。',
      onOk: async () => {
        try {
          const response = await axios.delete(`/api/news/${newsId}`, {
            headers: {
              'user-id': user?.id,
              'user-role': user?.role
            }
          })
          if (response.data.success) {
            Message.success('删除成功')
            fetchNews()
          } else {
            Message.error('删除失败：' + (response.data.message || '未知错误'))
          }
        } catch (error) {
          console.error('删除新闻失败:', error)
          Message.error('删除失败：' + (error.response?.data?.message || '网络错误'))
        }
      }
    })
  }

  const closeModal = () => {
    setShowDetailModal(false)
    setShowContentModal(false)
    setSelectedNews(null)
  }

  const handleExport = async (exportTimeRange = null) => {
    setExportLoading(true)
    try {
      const response = await axios.post('/api/news/export', {
        timeRange: activeTab,
        exportTimeRange: exportTimeRange
      }, {
        responseType: 'blob'
      })

      const blob = new Blob([response.data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      })
      
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      
      const contentDisposition = response.headers['content-disposition']
      let filename = '舆情信息.xlsx'
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
        if (filenameMatch && filenameMatch[1]) {
          filename = decodeURIComponent(filenameMatch[1].replace(/['"]/g, ''))
        }
      }
      
      link.download = filename
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)
      
      setShowExportModal(false)
      Message.success('导出成功')
    } catch (error) {
      console.error('导出失败:', error)
      Message.error('导出失败，请重试')
    } finally {
      setExportLoading(false)
    }
  }

  const handleSelectNews = (newsId) => {
    setSelectedNewsIds(prev => {
      if (prev.includes(newsId)) {
        return prev.filter(id => id !== newsId)
      } else {
        return [...prev, newsId]
      }
    })
  }

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedNewsIds([])
    } else {
      setSelectedNewsIds(newsList.map(news => news.id))
    }
    setSelectAll(!selectAll)
  }

  useEffect(() => {
    if (newsList.length === 0) {
      setSelectAll(false)
      return
    }
    
    const currentPageNewsIds = newsList.map(news => news.id)
    const allCurrentPageSelected = currentPageNewsIds.length > 0 && 
      currentPageNewsIds.every(id => selectedNewsIds.includes(id))
    
    setSelectAll(allCurrentPageSelected)
  }, [newsList, selectedNewsIds])

  const handleBatchAnalysis = async () => {
    if (selectedNewsIds.length === 0) {
      Message.warning('请先选择要分析的新闻')
      return
    }

    if (!user || !user.id) {
      Message.warning('用户信息未加载，请刷新页面重试')
      return
    }

    Modal.confirm({
      title: '确认AI分析',
      content: `确定要对选中的 ${selectedNewsIds.length} 条新闻进行AI重新分析吗？\n\n分析过程可能需要一些时间，请耐心等待。`,
      onOk: async () => {
        setBatchAnalysisLoading(true)
        try {
          const response = await axios.post('/api/news-analysis/batch-analyze-selected', {
            newsIds: selectedNewsIds
          })
          
          if (response.data.success) {
            if (response.data.status === 'processing') {
              const taskId = response.data.taskId
              setCurrentTaskId(taskId)
              
              setAnalysisProgress({
                status: 'processing',
                total: response.data.data.total,
                processed: 0,
                successCount: 0,
                errorCount: 0,
                percentage: 0,
                currentItem: null,
                estimatedTimeLeft: null
              })
              
              Message.success(`AI分析已开始！正在后台处理 ${response.data.data.total} 条新闻`)
              
              setSelectedNewsIds([])
              setSelectAll(false)
              
              setTimeout(() => checkAnalysisProgress(taskId), 1000)
            } else {
              Message.success(`AI分析完成！处理了 ${response.data.processed || selectedNewsIds.length} 条新闻，成功: ${response.data.successCount || 0} 条，失败: ${response.data.errorCount || 0} 条`)
              fetchNews()
              setSelectedNewsIds([])
              setSelectAll(false)
            }
          } else {
            Message.error('分析失败：' + (response.data.message || '未知错误'))
          }
        } catch (error) {
          console.error('批量分析失败:', error)
          let errorMessage = '分析失败：'
          if (error.code === 'ECONNABORTED') {
            errorMessage += '请求超时。如果您看到此消息，AI分析可能仍在后台进行中，请等待几分钟后刷新页面查看结果'
          } else if (error.response) {
            errorMessage += `服务器错误 (${error.response.status}): ${error.response.data?.message || error.response.statusText}`
          } else if (error.request) {
            errorMessage += '网络连接超时或服务器无响应。分析可能仍在后台进行，请稍后刷新页面查看结果'
          } else {
            errorMessage += error.message || '未知错误'
          }
          Message.error(errorMessage)
        } finally {
          setBatchAnalysisLoading(false)
        }
      }
    })
  }

  const columns = [
    ...(shouldShowCheckbox() ? [{
      title: (
        <Checkbox
          checked={selectAll && newsList.length > 0}
          onChange={handleSelectAll}
        />
      ),
      width: 60,
      render: (_, record) => (
        <Checkbox
          checked={selectedNewsIds.includes(record.id)}
          onChange={() => handleSelectNews(record.id)}
        />
      )
    }] : []),
    {
      title: '序号',
      width: 80,
      render: (_, record, index) => (currentPage - 1) * pageSize + index + 1
    },
    {
      title: '被投企业全称',
      dataIndex: 'enterprise_full_name',
      width: 200,
      ellipsis: true,
      tooltip: true,
      render: (text) => text || '-'
    },
    {
      title: '关键词',
      dataIndex: 'keywords',
      width: 200,
      render: (keywords) => {
        if (keywords && Array.isArray(keywords) && keywords.length > 0) {
          return (
            <Space wrap>
              {keywords.slice(0, 3).map((keyword, idx) => (
                <Tag key={idx} size="small">
                  {keyword.length > 4 ? `${keyword.substring(0, 4)}...` : keyword}
                </Tag>
              ))}
              {keywords.length > 3 && (
                <Tag size="small" color="gray">
                  +{keywords.length - 3}
                </Tag>
              )}
            </Space>
          )
        }
        return '-'
      }
    },
    {
      title: '发布时间',
      dataIndex: 'public_time',
      width: 180,
      render: (text) => formatDate(text)
    },
    {
      title: '标题',
      dataIndex: 'title',
      width: 300,
      ellipsis: true,
      tooltip: true,
      render: (text) => text || '-'
    },
    {
      title: '新闻摘要',
      dataIndex: 'news_abstract',
      width: 300,
      ellipsis: true,
      tooltip: true,
      render: (text) => text || '-'
    },
    {
      title: '文章链接',
      dataIndex: 'source_url',
      width: 120,
      render: (text) => text ? (
        <Button type="text" size="small" onClick={() => window.open(text, '_blank')}>
          查看文章
        </Button>
      ) : '-'
    },
    {
      title: '公众号名称',
      dataIndex: 'account_name',
      width: 150,
      ellipsis: true,
      tooltip: true,
      render: (text) => text || '-'
    },
    {
      title: '微信账号',
      dataIndex: 'wechat_account',
      width: 150,
      ellipsis: true,
      tooltip: true,
      render: (text) => text || '-'
    },
    ...(isAdmin ? [{
      title: '创建时间',
      dataIndex: 'created_at',
      width: 180,
      render: (text) => formatDate(text)
    }, {
      title: '操作',
      width: 200,
      render: (_, record) => (
        <Space size={8}>
          <Button
            type="outline"
            size="small"
            onClick={() => handleViewDetail(record)}
          >
            详情
          </Button>
          {record.content && (
            <Button
              type="outline"
              size="small"
              status="success"
              onClick={() => handleViewContent(record)}
            >
              正文
            </Button>
          )}
          <Button
            type="outline"
            size="small"
            status="danger"
            onClick={() => handleDelete(record.id)}
          >
            删除
          </Button>
        </Space>
      )
    }] : [])
  ]

  return (
    <div className="news-info">
      <Tabs
        activeTab={adminActiveTab}
        onChange={setAdminActiveTab}
        type="line"
        className="admin-tabs"
      >
        <TabPane key="news" title="舆情信息">
          <Card className="news-card" bordered={false}>
            <div className="news-header">
              <h2>
                舆情信息
                {isAdmin && <Tag color="orange" style={{ marginLeft: '8px' }}>（管理员 - 全部数据）</Tag>}
                {!isAdmin && <Tag color="blue" style={{ marginLeft: '8px' }}>（我的企业相关）</Tag>}
              </h2>
              <InputSearch
                value={search}
                onChange={(value) => setSearch(value)}
                placeholder="搜索标题、公众号名称或微信号..."
                style={{ width: 400 }}
                allowClear
                onSearch={handleSearch}
              />
            </div>

            {isAdmin && (
              <Card className="stats-card" style={{ marginBottom: '16px' }}>
                <Space size="large">
                  <div>
                    <div className="stats-label">总舆情数量</div>
                    <div className="stats-value">{total.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="stats-label">当前页显示</div>
                    <div className="stats-value">{newsList.length}</div>
                  </div>
                  <div>
                    <div className="stats-label">总页数</div>
                    <div className="stats-value">{totalPages}</div>
                  </div>
                </Space>
              </Card>
            )}

            {!isAdmin && userStats && (
              <Card className="stats-card" style={{ marginBottom: '16px' }}>
                <Space size="large">
                  <div>
                    <div className="stats-label">昨日发布新闻企业个数</div>
                    <div className="stats-value highlight">{userStats.yesterdayAccountsCount || 0}</div>
                  </div>
                  <div>
                    <div className="stats-label">昨日累计新闻条数</div>
                    <div className="stats-value highlight">{userStats.yesterdayCount || 0}</div>
                  </div>
                  <div>
                    <div className="stats-label">当前总关注被投企业个数</div>
                    <div className="stats-value highlight-blue">{userStats.totalEnterprises || 0}</div>
                  </div>
                </Space>
              </Card>
            )}

            <Tabs
              activeTab={activeTab}
              onChange={handleTabChange}
              type="line"
              className="time-range-tabs"
            >
              <TabPane key="yesterday" title="昨日舆情" />
              <TabPane key="thisWeek" title="本周舆情" />
              <TabPane key="lastWeek" title="上周舆情" />
              <TabPane key="thisMonth" title="本月舆情" />
              <TabPane key="all" title="全部舆情" />
            </Tabs>

            <div className="toolbar">
              <Space>
                {activeTab === 'all' ? (
                  <Button
                    type="outline"
                    onClick={() => setShowExportModal(true)}
                    loading={exportLoading}
                  >
                    导出
                  </Button>
                ) : (
                  <Button
                    type="outline"
                    onClick={() => handleExport()}
                    loading={exportLoading}
                  >
                    导出
                  </Button>
                )}
                
                {shouldShowCheckbox() && selectedNewsIds.length > 0 && (
                  <Button
                    type="outline"
                    status="warning"
                    onClick={handleBatchAnalysis}
                    loading={batchAnalysisLoading}
                  >
                    AI分析({selectedNewsIds.length})
                  </Button>
                )}

                {(analysisProgress && analysisProgress.status === 'processing') && (
                  <Card className="progress-card" style={{ padding: '12px', marginTop: '16px' }}>
                    <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontWeight: 600 }}>AI分析进行中</span>
                      <span style={{ fontSize: '14px', color: '#4e5969' }}>
                        {analysisProgress?.processed || 0}/{analysisProgress?.total || 0} ({analysisProgress?.percentage || 0}%)
                      </span>
                    </div>
                    <Progress
                      percent={analysisProgress?.percentage || 0}
                      status="normal"
                      style={{ marginBottom: '8px' }}
                    />
                    <div style={{ fontSize: '12px', color: '#86909c', display: 'flex', justifyContent: 'space-between' }}>
                      <span>成功: {analysisProgress?.successCount || 0} 失败: {analysisProgress?.errorCount || 0}</span>
                      <Button type="text" size="mini" onClick={cancelAnalysis}>取消</Button>
                    </div>
                  </Card>
                )}

                {analysisProgress && analysisProgress.status === 'completed' && (
                  <Card className="completed-card" style={{ padding: '12px', marginTop: '16px', background: '#f0f9ff' }}>
                    <Space>
                      <Tag color="green">✅</Tag>
                      <span>
                        分析完成！处理了 {analysisProgress.total} 条新闻，成功 {analysisProgress.successCount} 条，失败 {analysisProgress.errorCount} 条
                      </span>
                    </Space>
                  </Card>
                )}

                {isAdmin && (
                  <Button
                    type="outline"
                    status="warning"
                    onClick={cleanInvalidAssociations}
                  >
                    清理无效关联
                  </Button>
                )}

                <Button
                  onClick={handleRefreshList}
                  loading={isRefreshing}
                >
                  刷新
                </Button>
              </Space>
            </div>

            <RadioGroup
              value={enterpriseFilter}
              onChange={(value) => {
                setEnterpriseFilter(value)
                setCurrentPage(1)
                setSelectedNewsIds([])
                setSelectAll(false)
              }}
              type="button"
              style={{ marginBottom: '16px' }}
            >
              <Radio value="enterprise">企业相关</Radio>
              <Radio value="all">全部</Radio>
            </RadioGroup>

            <div className="table-container">
              {loading && newsList.length === 0 ? (
                <Skeleton
                  loading={true}
                  animation={true}
                  text={{ rows: 8, width: ['100%'] }}
                />
              ) : (
                <Table
                  columns={columns}
                  data={newsList}
                  loading={loading}
                  pagination={false}
                  rowKey="id"
                  border={{
                    wrapper: true,
                    cell: true
                  }}
                  stripe
                />
              )}
            </div>

            {total > 0 && (
              <div className="pagination-wrapper">
                <div className="page-size-selector">
                  <span className="page-size-label">每页显示：</span>
                  <Select
                    value={pageSize}
                    onChange={handlePageSizeChange}
                    style={{ width: 100 }}
                  >
                    <Option value={10}>10</Option>
                    <Option value={20}>20</Option>
                    <Option value={30}>30</Option>
                    <Option value={50}>50</Option>
                    <Option value={100}>100</Option>
                  </Select>
                  <span className="page-size-unit">条</span>
                </div>
                <Pagination
                  current={currentPage}
                  total={total}
                  pageSize={pageSize}
                  onChange={(page) => setCurrentPage(page)}
                  showTotal
                  showJumper
                />
              </div>
            )}
          </Card>
        </TabPane>

        <TabPane key="accounts" title="公众号管理">
          <AdditionalAccounts />
        </TabPane>

        <TabPane key="recipients" title="收件管理">
          {!isAdmin ? (
            <Tabs
              activeTab={recipientTab}
              onChange={setRecipientTab}
              type="line"
            >
              <TabPane key="recipients" title="收件管理">
                <RecipientManagement />
              </TabPane>
              <TabPane key="records" title="收发记录">
                <UserEmailRecords activeTab="records" />
              </TabPane>
              <TabPane key="logs" title="邮件日志">
                <UserEmailRecords activeTab="logs" />
              </TabPane>
            </Tabs>
          ) : (
            <RecipientManagement />
          )}
        </TabPane>
      </Tabs>

      {/* 详情模态框 */}
      <Modal
        visible={showDetailModal}
        title="舆情详情"
        onCancel={closeModal}
        footer={null}
        style={{ width: 600 }}
      >
        {selectedNews && (
          <div className="detail-content">
            <div className="detail-row">
              <label>公众号名称：</label>
              <span>{selectedNews.account_name || '-'}</span>
            </div>
            <div className="detail-row">
              <label>微信账号：</label>
              <span>{selectedNews.wechat_account || '-'}</span>
            </div>
            <div className="detail-row">
              <label>发布时间：</label>
              <span>{formatDate(selectedNews.public_time)}</span>
            </div>
            <div className="detail-row">
              <label>创建时间：</label>
              <span>{formatDate(selectedNews.created_at)}</span>
            </div>
            <div className="detail-row">
              <label>文章标题：</label>
              <span>{selectedNews.title || '-'}</span>
            </div>
            {selectedNews.summary && (
              <div className="detail-row">
                <label>文章摘要：</label>
                <span>{selectedNews.summary}</span>
              </div>
            )}
            <div className="detail-row">
              <label>原文链接：</label>
              <span>
                {selectedNews.source_url ? (
                  <a href={selectedNews.source_url} target="_blank" rel="noopener noreferrer">
                    {selectedNews.source_url}
                  </a>
                ) : '-'}
              </span>
            </div>
            {selectedNews.keywords && selectedNews.keywords.length > 0 && (
              <div className="detail-row">
                <label>关键词：</label>
                <Space wrap>
                  {selectedNews.keywords.map((keyword, idx) => (
                    <Tag key={idx}>{keyword}</Tag>
                  ))}
                </Space>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* 正文模态框 */}
      <Modal
        visible={showContentModal}
        title="文章正文"
        onCancel={closeModal}
        footer={null}
        style={{ width: 800 }}
      >
        {selectedNews && (
          <div>
            <div style={{ marginBottom: '16px' }}>
              <h3>{selectedNews.title}</h3>
              <p style={{ color: '#86909c', fontSize: '14px' }}>
                {selectedNews.account_name} · {formatDate(selectedNews.public_time)}
              </p>
            </div>
            <Divider />
            <div>
              {selectedNews.content ? (
                <div dangerouslySetInnerHTML={{ __html: selectedNews.content }} />
              ) : (
                <p>暂无正文内容</p>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* 导出选择模态框 */}
      <Modal
        visible={showExportModal}
        title="选择导出范围"
        onCancel={() => setShowExportModal(false)}
        footer={null}
        style={{ width: 600 }}
      >
        <div className="export-options">
          <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <Button
              type="outline"
              long
              onClick={() => handleExport('thisWeek')}
              loading={exportLoading}
            >
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontWeight: 600, marginBottom: '4px' }}>本周舆情</div>
                <div style={{ fontSize: '12px', color: '#86909c' }}>导出本周一至今的舆情信息</div>
              </div>
            </Button>
            <Button
              type="outline"
              long
              onClick={() => handleExport('thisMonth')}
              loading={exportLoading}
            >
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontWeight: 600, marginBottom: '4px' }}>本月舆情</div>
                <div style={{ fontSize: '12px', color: '#86909c' }}>导出本月1日至今的舆情信息</div>
              </div>
            </Button>
            <Button
              type="outline"
              long
              onClick={() => handleExport('lastMonth')}
              loading={exportLoading}
            >
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontWeight: 600, marginBottom: '4px' }}>上月舆情</div>
                <div style={{ fontSize: '12px', color: '#86909c' }}>导出上个月的舆情信息</div>
              </div>
            </Button>
            <Button
              type="outline"
              long
              onClick={() => handleExport('all')}
              loading={exportLoading}
            >
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontWeight: 600, marginBottom: '4px' }}>全部舆情</div>
                <div style={{ fontSize: '12px', color: '#86909c' }}>导出所有舆情信息</div>
              </div>
            </Button>
          </Space>
        </div>
      </Modal>
    </div>
  )
}

export default NewsInfo

